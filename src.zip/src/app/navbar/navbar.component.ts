import { Component } from '@angular/core';
import { ActivatedRoute, Router, ParamMap } from '@angular/router';
import {Location} from '@angular/common'


@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css',],
  
})
export class NavbarComponent {

  userId: any;
  signuplit: Boolean;
  qnalit: Boolean;
  dashboardlit: Boolean;
  prevqlit:Boolean;
  


  constructor(private route:ActivatedRoute,private router:Router,private location: Location)
   {
       this.userId=0;
      this.signuplit=false;
      this.qnalit=false;
      this.dashboardlit=false;
      this.prevqlit=false;
   }

   ngOnInit()
   {
    
       this.route.paramMap.subscribe((params: ParamMap)=> {
        //this.userId=params.get('userid')
      })
      var routeinstr=this.location.path();
      if (routeinstr=='' || routeinstr=="/signup")
      {
        this.signuplit=true;
      }
      else if(routeinstr.startsWith('/teams') || routeinstr.startsWith('/qna'))
      {
        this.qnalit=true;
      }
      else if (routeinstr.startsWith('/dashboard'))
      {
        this.dashboardlit=true;
      }
   }
    signup()
    {
      this.router.navigate(['/signup'])
      this.signuplit=true;
      this.qnalit=false;
      this.dashboardlit=false;
      this.prevqlit=false;
    }

    qna()
    {
      this.router.navigate(['/teams',{'userid':this.userId}])
      this.signuplit=false;
      this.qnalit=true;
      this.dashboardlit=false;
      this.prevqlit=false;
    }

    dashboard()
    {
      this.router.navigate(['/dashboard',{'userid':this.userId}])
      this.signuplit=false;
      this.qnalit=false;
      this.dashboardlit=true;
      this.prevqlit=false;
    }

    
}
