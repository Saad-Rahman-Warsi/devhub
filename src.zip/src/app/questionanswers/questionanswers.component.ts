import { Component } from '@angular/core';
import { Question } from '../model/Question';

@Component({
  selector: 'app-questionanswers',
  templateUrl: './questionanswers.component.html',
  styleUrls: ['./questionanswers.component.css']
})
export class QuestionanswersComponent {
     question1:Question={"question":"what is maths", "askedby":{"userid":0,"username":"saad",password:"saad"},"answers":[{"answer":"maths is good","answeredby":{"userid":0,"username":"saad","password":"saad"}}]};
     question2:Question={"question":"what is maths", "askedby":{"userid":0,"username":"saad",password:"saad"},"answers":[{"answer":"maths is good","answeredby":{"userid":0,"username":"saad","password":"saad"}},{"answer":"maths is very good","answeredby":{"userid":0,"username":"saad","password":"saad"}},{"answer":"maths is ok","answeredby":{"userid":0,"username":"saad","password":"saad"}}]};
}
