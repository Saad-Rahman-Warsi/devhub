import { Component } from '@angular/core';
import { SignupService } from '../signup.service';

import { ActivatedRoute, Router, ParamMap } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent {
    users:any;
    error:any;
    usernameinput:any;
    passwordinput:any;
    signuperror:any;

    constructor(private signupservice: SignupService,private route:ActivatedRoute,private router:Router)
    {
        
    }

    ngOnInit()
    {   
        this.signupservice.getEmployees();
    }

    signup()
    {
      
      this.router.navigate(['/dashboard',{'userid':0}])
      var user:any;
        for (user in this.users)
        {
           if (user.name==this.usernameinput && user.password==this.passwordinput)
           {
            console.log(user.name);
            console.log(this.usernameinput);
            console.log(user.password);
            console.log(this.passwordinput);
            this.router.navigate(['/dashboard',{'userid':user.userid}])
           }
           else
           {
              this.signuperror="incorrect username or password";
           }
       }
      }
    }
  
