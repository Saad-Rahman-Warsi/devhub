import { User } from "./User";

export interface Answer
{
    answer:string;
    answeredby:User;
}