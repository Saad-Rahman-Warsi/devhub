export interface Team
{
    name: string;
    subteams: Team[];
}