import { User } from "./User";
import { Answer } from "./Answer";

export interface Question{
    question:string;
    askedby:User;
    answers:Answer[];
}