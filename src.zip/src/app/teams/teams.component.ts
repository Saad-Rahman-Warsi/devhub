import { Component } from '@angular/core';
import { Team } from '../model/Team';


@Component({
  selector: 'app-teams',
  templateUrl: './teams.component.html',
  styleUrls: ['./teams.component.css']
})
export class TeamsComponent {
    teams:Team={"name":"cra","subteams":[{"name":"technical","subteams":[{"name":"devops","subteams":[]},{"name":"development","subteams":[]},{"name":"operations","subteams":[]}]},{"name":"sales","subteams":[]}]};
 
    }
  
