import { Component, Input } from '@angular/core';
import {Question} from '../model/Question'
import { Answer } from '../model/Answer';

@Component({
  selector: 'app-questionanswer',
  templateUrl: './questionanswer.component.html',
  styleUrls: ['./questionanswer.component.css']
})
export class QuestionanswerComponent {
    @Input()
    question:any;

    toggle:Boolean=false;
    view:Answer[]=[];

    showanswer()
    {
       if (this.toggle==true)
       {
        this.toggle=false;
        this.view=[];
       }
       else
       {
         this.toggle=true;
         this.view=this.question.answers;
       }
    }

    postanswer()
    {

    }
}
