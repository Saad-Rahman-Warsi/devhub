import { Component } from '@angular/core';
import { GetserviceService } from '../getservice.service';
import { ActivatedRoute, Router, ParamMap } from '@angular/router';
import { NavbarComponent } from '../navbar/navbar.component';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent {
    userid:any;
    username:any;
    error:any;
    state:number=0;

    constructor(private service:GetserviceService,private route:ActivatedRoute,private router:Router)
     {
      
     }

    ngOnInit()
    {
      this.route.paramMap.subscribe((params: ParamMap)=> {
        this.userid=params.get('userid')
      })
      this.service.getEmployeeById(this.userid).subscribe(data => this.username=data, error=>this.error);
    }

    dashboard()
    {

    }

    notification()
    {

    }

    activity()
    {

    }

    postques()
    {

    }

    account()
    {

    }

    viewques()
    {
      this.state=5;
    }
}
