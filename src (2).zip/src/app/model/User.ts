export interface User
{
     userid:Number;
     username:String;
     password:String;
}