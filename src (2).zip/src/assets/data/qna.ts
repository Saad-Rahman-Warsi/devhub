export const QNA=[{
                    "teamid":0,
                    "questions":[
                                {
                                    "questionid":0,
                                    "questiontitle":"what is maths",
                                    "questiondescription":"what is maths",
                                     "askedby":0,
                                     "answers":
                                     [
                                        {"answer":"maths is good","answeredby":0}
                                    ]
                                },
                                {
                                    "questionid":1, 
                                    "questiontitle":"what is computer",
                                    "questiondescription":"what is computer",
                                    "askedby":0,
                                    "answers":[
                                        {"answer":"computer is good","answeredby":0}
                                    ]
                                }
                            ]},
                  {
                        "teamid":1,
                        "questions":[
                        {
                            "questionid":2,
                            "questiontitle":"what is chemistry",
                            "questiondescription":"what is chemistry",
                            "askedby":0,
                            "answers":[
                                        {"answer":"chemistry is good","answeredby":0},
                                        {"answer":"chemistry is very good","answeredby":0},
                                        {"answer":"chemistry is ok","answeredby":0}
                                    ]
                        }
            ]
        }
    ]