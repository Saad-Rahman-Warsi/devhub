export const TEAMS:any = [
    {"teamid":0,"name":"cra","subteams":[1,2]},
    {"teamid":1,"name":"technical","subteams":[3,4,5]},
    {"teamid":2,"name":"sales","subteams":[]},
    {"teamid":3,"name":"development","subteams":[]},
    {"teamid":4,"name":"devops","subteams":[]},
    {"teamid":5,"name":"operations","subteams":[]}
];