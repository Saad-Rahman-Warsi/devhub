export const ACCESS=[
    {"userid":0,"canaccess":[2,3]},
    {"userid":1,"canaccess":[0]},
    {"userid":2,"canaccess":[3,5]}
]