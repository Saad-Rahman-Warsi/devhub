export const USERS:any = [
    {"userid":0,"username":"saad","password":"saad"},
    {"userid":1,"username":"ahmed","password":"ahmed"},
    {"userid":2,"username":"hamid","password":"hamid"}
];